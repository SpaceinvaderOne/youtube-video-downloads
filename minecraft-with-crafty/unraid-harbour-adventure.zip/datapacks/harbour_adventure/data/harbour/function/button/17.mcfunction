scoreboard players set #b17 hr 1
function harbour:race/start_near
