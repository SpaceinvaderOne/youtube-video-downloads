scoreboard players set #b11 hr 1
function harbour:zfs/purple
