scoreboard players set #b16 hr 1
function harbour:admin/confirm
