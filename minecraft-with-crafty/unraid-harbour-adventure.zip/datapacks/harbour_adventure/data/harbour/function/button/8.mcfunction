scoreboard players set #b8 hr 1
function harbour:cinema/right
