scoreboard players set #b2 hr 1
function harbour:mission/finish
