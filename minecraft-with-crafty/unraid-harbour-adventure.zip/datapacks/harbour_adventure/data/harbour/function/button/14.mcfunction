scoreboard players set #b14 hr 1
function harbour:bonus/exit
