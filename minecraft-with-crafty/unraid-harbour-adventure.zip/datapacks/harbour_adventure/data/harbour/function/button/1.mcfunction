scoreboard players set #b1 hr 1
function harbour:player/guide_near
