scoreboard players set #b0 hr 1
function harbour:mission/start
