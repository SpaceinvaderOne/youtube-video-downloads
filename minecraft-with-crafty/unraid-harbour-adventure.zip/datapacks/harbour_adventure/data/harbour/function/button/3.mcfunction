scoreboard players set #b3 hr 1
function harbour:bonus/enter
