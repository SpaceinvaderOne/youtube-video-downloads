scoreboard players set #b12 hr 1
function harbour:zfs/yellow
