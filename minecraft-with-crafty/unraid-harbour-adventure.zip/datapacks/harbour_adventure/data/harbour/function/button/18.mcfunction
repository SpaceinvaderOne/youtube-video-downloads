scoreboard players set #b18 hr 1
function harbour:race/cancel_near
