scoreboard players set #b15 hr 1
function harbour:admin/arm
