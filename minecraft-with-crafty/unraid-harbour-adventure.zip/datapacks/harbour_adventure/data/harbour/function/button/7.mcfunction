scoreboard players set #b7 hr 1
function harbour:cinema/wrong
