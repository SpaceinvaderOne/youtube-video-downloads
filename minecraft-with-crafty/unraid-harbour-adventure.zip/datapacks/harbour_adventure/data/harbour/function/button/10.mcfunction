scoreboard players set #b10 hr 1
function harbour:zfs/blue
