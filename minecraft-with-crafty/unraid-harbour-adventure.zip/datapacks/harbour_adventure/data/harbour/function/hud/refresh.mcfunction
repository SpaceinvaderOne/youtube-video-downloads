scoreboard players set #total hr 0
scoreboard players operation #total hr += #docker hr
scoreboard players operation #total hr += #cinema hr
scoreboard players operation #total hr += #zfs hr
scoreboard players operation #total hr += #backup hr
execute store result bossbar harbour:progress value run scoreboard players get #total hr
bossbar set harbour:progress players @a[tag=hr_joined]
execute if score #state hr matches 1..2 run bossbar set harbour:progress visible true
execute if score #state hr matches 0 run bossbar set harbour:progress visible false
execute if score #state hr matches 3 run bossbar set harbour:progress visible false
execute if score #total hr matches 4 if score #state hr matches 1 run function harbour:mission/ready
