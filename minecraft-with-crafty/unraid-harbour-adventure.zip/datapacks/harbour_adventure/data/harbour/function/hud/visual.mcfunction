execute if loaded 9 70 -46 if score #docker hr matches 0 unless block 9 70 -46 minecraft:red_concrete run setblock 9 70 -46 minecraft:red_concrete
execute if loaded 9 70 -46 if score #docker hr matches 1 unless block 9 70 -46 minecraft:sea_lantern run setblock 9 70 -46 minecraft:sea_lantern
execute if loaded 11 70 -46 if score #cinema hr matches 0 unless block 11 70 -46 minecraft:red_concrete run setblock 11 70 -46 minecraft:red_concrete
execute if loaded 11 70 -46 if score #cinema hr matches 1 unless block 11 70 -46 minecraft:sea_lantern run setblock 11 70 -46 minecraft:sea_lantern
execute if loaded 13 70 -46 if score #zfs hr matches 0 unless block 13 70 -46 minecraft:red_concrete run setblock 13 70 -46 minecraft:red_concrete
execute if loaded 13 70 -46 if score #zfs hr matches 1 unless block 13 70 -46 minecraft:sea_lantern run setblock 13 70 -46 minecraft:sea_lantern
execute if loaded 15 70 -46 if score #backup hr matches 0 unless block 15 70 -46 minecraft:red_concrete run setblock 15 70 -46 minecraft:red_concrete
execute if loaded 15 70 -46 if score #backup hr matches 1 unless block 15 70 -46 minecraft:sea_lantern run setblock 15 70 -46 minecraft:sea_lantern
execute if loaded -101 74 -29 if score #cinema hr matches 0 unless block -101 74 -29 minecraft:purple_concrete run fill -101 74 -29 -97 74 -29 minecraft:purple_concrete
execute if loaded -101 74 -29 if score #cinema hr matches 1 unless block -101 74 -29 minecraft:sea_lantern run fill -101 74 -29 -97 74 -29 minecraft:sea_lantern
