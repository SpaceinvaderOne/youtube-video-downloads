execute unless data storage harbour:state initialized run function harbour:bootstrap
scoreboard players set #twenty hr 20
scoreboard players set #two hr 2
execute if score #installed hr matches 0 run function harbour:install/request
execute if score #installed hr matches 1 run function harbour:hud/refresh
