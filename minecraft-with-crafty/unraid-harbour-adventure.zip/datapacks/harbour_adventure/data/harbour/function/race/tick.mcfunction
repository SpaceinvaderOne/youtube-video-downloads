scoreboard players add #time hr 1
execute unless entity @a[tag=hr_racer] run function harbour:race/cancel
scoreboard players set @a[tag=hr_racer] hr_boat 0
execute as @a[tag=hr_racer] store success score @s hr_boat on vehicle if entity @s[type=minecraft:oak_boat]
execute as @a[tag=hr_racer,scores={hr_boat=0}] run function harbour:race/cancel
execute if score #time hr matches 6000.. run function harbour:race/cancel
execute if score #lap hr matches 0 if entity @a[tag=hr_racer,x=-132,y=64,z=55,dx=7,dy=6,dz=10] run scoreboard players set #lap hr 1
execute if score #lap hr matches 1 if entity @a[tag=hr_racer,x=-141,y=64,z=55,dx=6,dy=6,dz=10] run scoreboard players set #lap hr 2
execute if score #lap hr matches 2 as @a[tag=hr_racer,x=-141,y=64,z=-50,dx=6,dy=6,dz=10] run function harbour:race/finish
