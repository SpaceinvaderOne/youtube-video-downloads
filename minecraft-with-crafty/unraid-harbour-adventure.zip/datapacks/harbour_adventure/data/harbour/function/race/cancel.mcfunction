scoreboard players set #race hr 0
execute as @a[tag=hr_racer] run ride @s dismount
tp @a[tag=hr_racer] -122 65 -57 0 0
tellraw @a[tag=hr_racer] {"text":"Time trial cancelled. Press START to try again.","color":"yellow"}
tag @a remove hr_racer
kill @e[type=minecraft:oak_boat,tag=hr_raceboat]
