scoreboard players set #race hr 1
scoreboard players set #time hr 0
scoreboard players set #lap hr 0
tag @s add hr_racer
tp @s -130 65 -45 0 0
summon minecraft:oak_boat -130 65 -45 {Tags:["hr_raceboat"],Invulnerable:1b}
execute positioned -130 65 -45 run ride @s mount @e[type=minecraft:oak_boat,tag=hr_raceboat,distance=..3,limit=1,sort=nearest]
tellraw @s {"text":"GO! South along the EAST lane. Cross to the WEST lane at the far end, then return NORTH. SHIFT cancels.","color":"aqua"}
