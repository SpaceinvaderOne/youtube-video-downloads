scoreboard players operation @s hr_last = #time hr
execute unless score @s hr_best matches 1.. run scoreboard players operation @s hr_best = #time hr
execute if score @s hr_last < @s hr_best run scoreboard players operation @s hr_best = @s hr_last
scoreboard players operation #seconds hr = #time hr
scoreboard players operation #seconds hr /= #twenty hr
scoreboard players operation #decimal hr = #time hr
scoreboard players operation #decimal hr %= #twenty hr
scoreboard players operation #decimal hr /= #two hr
tellraw @a [{"selector":"@s"},{"text":" completed SSD Express in "},{"score":{"name":"#seconds","objective":"hr"}},{"text":"."},{"score":{"name":"#decimal","objective":"hr"}},{"text":" seconds!"}]
scoreboard players set #race hr 0
ride @s dismount
tp @s -122 65 -57 0 0
tag @s remove hr_racer
kill @e[type=minecraft:oak_boat,tag=hr_raceboat]
