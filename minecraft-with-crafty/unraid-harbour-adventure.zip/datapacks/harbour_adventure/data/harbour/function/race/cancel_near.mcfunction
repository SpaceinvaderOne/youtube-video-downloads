execute as @p[tag=hr_racer,distance=..10] at @s run function harbour:race/cancel
