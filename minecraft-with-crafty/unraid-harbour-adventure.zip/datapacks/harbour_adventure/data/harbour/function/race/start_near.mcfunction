execute if score #race hr matches 1 run tellraw @p[distance=..6] {"text":"The SSD course has an active racer. Start control is available again when the run ends.","color":"aqua"}
execute if score #race hr matches 0 as @p[distance=..6] at @s run function harbour:race/start
