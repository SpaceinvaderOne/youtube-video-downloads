scoreboard players set #clock hr 0
function harbour:hud/refresh
function harbour:hud/visual
scoreboard players operation #seconds hr = #time hr
scoreboard players operation #seconds hr /= #twenty hr
execute if score #race hr matches 1 run title @a[tag=hr_racer] actionbar [{"text":"SSD Express | seconds: ","color":"aqua"},{"score":{"name":"#seconds","objective":"hr"}},{"text":" | checkpoint "},{"score":{"name":"#lap","objective":"hr"}},{"text":"/2"}]
