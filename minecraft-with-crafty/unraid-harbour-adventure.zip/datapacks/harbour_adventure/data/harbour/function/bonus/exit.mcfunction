tp @p[distance=..7] 22 65 -49 180 0
