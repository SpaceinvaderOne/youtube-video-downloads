execute if score #state hr matches 3 as @p[distance=..6] run tp @s 146 66 57 180 0
execute unless score #state hr matches 3 run tellraw @a {"text":"The maintenance lounge is a bonus for completing the mission. Everything else is open.","color":"aqua"}
