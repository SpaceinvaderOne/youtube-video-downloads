scoreboard players set #cinema hr 1
tellraw @a {"text":"Cinema service recovered. Signal sent to Unraid HQ.","color":"green"}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1
function harbour:hud/refresh
execute as @a[tag=hr_joined] run function harbour:player/directions
