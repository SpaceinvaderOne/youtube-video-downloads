scoreboard players set #docker hr 1
tellraw @a {"text":"Docker recovery module recovered. Signal sent to Unraid HQ.","color":"green"}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1
function harbour:hud/refresh
execute as @a[tag=hr_joined] run function harbour:player/directions
