execute if score #state hr matches 1 if score #zfs hr matches 0 run function harbour:zfs/yellow_active
execute if score #state hr matches 0 run tellraw @a {"text":"First right-click the grey button below the orange marker in the welcome plaza.","color":"aqua"}
