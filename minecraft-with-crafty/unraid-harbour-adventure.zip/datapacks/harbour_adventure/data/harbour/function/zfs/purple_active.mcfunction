scoreboard players set #valid hr 0
execute if score #sequence hr matches 1 run scoreboard players set #valid hr 1
execute if score #valid hr matches 0 run scoreboard players set #sequence hr 0
execute if score #valid hr matches 0 run tellraw @a {"text":"Sequence reset. Read POOL RECOVERY on the east wall at XYZ -61, 69, -98. Follow its four colours; repeats count. Let each button release.","color":"yellow"}
execute if score #valid hr matches 1 run scoreboard players add #sequence hr 1
execute if score #valid hr matches 1 run playsound minecraft:block.note_block.chime master @a ~ ~ ~ 1 1.2
execute if score #sequence hr matches 4 run function harbour:award/zfs
