tag @s add hr_joined
function harbour:player/guide
function harbour:player/directions
tellraw @s {"text":"You joined the recovery team. Complete the four activities in any order.","color":"green"}
