execute as @p[distance=..6] run function harbour:player/guide
