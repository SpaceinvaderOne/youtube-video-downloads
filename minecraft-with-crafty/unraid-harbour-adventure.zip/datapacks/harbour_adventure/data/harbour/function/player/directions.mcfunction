execute if score #docker hr matches 0 run tellraw @s {"text":"DOCKER: Giant whale and crane east of plaza. Read manifest at 110, 68, 4; parcel boards near 96, 65, 28.","color":"aqua"}
execute if score #cinema hr matches 0 run tellraw @s {"text":"JELLYFIN: Purple cinema west of plaza, entrance -95, 65, -30. Read the east-wall poster, then choose a ticket button.","color":"aqua"}
execute if score #zfs hr matches 0 run tellraw @s {"text":"ZFS: Northwest gardens, entrance -82, 65, -116. Read the east-wall POOL RECOVERY clue, then use the north buttons.","color":"aqua"}
execute if score #backup hr matches 0 run tellraw @s {"text":"BACKUP: Bunker west of ZFS, entrance -133, 65, -111. Follow the maze to the recovery-key button.","color":"aqua"}
