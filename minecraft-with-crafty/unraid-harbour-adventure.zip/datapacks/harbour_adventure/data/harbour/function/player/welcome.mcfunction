tag @s add hr_seen
tellraw @s {"text":"Welcome! Explore freely, or RIGHT-CLICK the small GREY button below the ORANGE marker in the plaza to start the mission.","color":"gold"}
tellraw @s {"text":"The grey button below the BLUE plaza marker gives a guide. Coloured squares are markers, not buttons. Use right-click, not left-click.","color":"aqua"}
