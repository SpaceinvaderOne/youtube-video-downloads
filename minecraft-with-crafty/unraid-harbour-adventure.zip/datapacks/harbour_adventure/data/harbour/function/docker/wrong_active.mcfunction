tellraw @a {"text":"Check CARGO MANIFEST beside the crane at XYZ 110, 68, 4, then choose its parcel at the three boards near 96, 65, 28.","color":"yellow"}
