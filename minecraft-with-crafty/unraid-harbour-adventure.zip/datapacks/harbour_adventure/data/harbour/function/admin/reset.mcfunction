scoreboard players set #state hr 0
scoreboard players set #docker hr 0
scoreboard players set #cinema hr 0
scoreboard players set #zfs hr 0
scoreboard players set #backup hr 0
scoreboard players set #sequence hr 0
scoreboard players set #armed hr 0
scoreboard players set #total hr 0
tp @a[x=140,y=65,z=53,dx=13,dy=6,dz=9] 22 65 -49 180 0
tag @a remove hr_joined
function harbour:hud/refresh
tellraw @a {"text":"Mission reset. The town and race records are unchanged. Use the grey button below the orange plaza marker to play again.","color":"gold"}
