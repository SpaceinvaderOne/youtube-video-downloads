execute if score #armed hr matches 1.. run function harbour:admin/reset
