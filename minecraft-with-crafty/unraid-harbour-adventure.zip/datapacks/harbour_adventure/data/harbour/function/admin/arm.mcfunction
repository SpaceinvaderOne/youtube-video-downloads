scoreboard players set #armed hr 100
tellraw @a {"text":"RESET ARMED for 5 seconds. CONFIRM beside this control resets shared mission progress for everyone.","color":"red"}
