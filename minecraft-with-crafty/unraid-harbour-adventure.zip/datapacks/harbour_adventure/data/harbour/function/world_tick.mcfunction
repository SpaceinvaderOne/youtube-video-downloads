execute as @a[tag=!hr_seen] run function harbour:player/welcome
execute as @a[tag=hr_racer] unless score #race hr matches 1 run tag @s remove hr_racer
execute if score #armed hr matches 1.. run scoreboard players remove #armed hr 1
function harbour:sensors
execute if score #race hr matches 1 run function harbour:race/tick
scoreboard players add #clock hr 1
execute if score #clock hr matches 20.. run function harbour:slow_tick
