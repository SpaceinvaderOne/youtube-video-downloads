fill -19 64 27 -17 64 30 minecraft:smooth_quartz
fill -19 65 29 -17 69 29 minecraft:polished_blackstone
setblock -18 69 29 minecraft:orange_concrete
setblock -18 68 28 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["OPTIONAL MISSION","Bring the lab online","Press to join","Shared team progress"],color:"white",has_glowing_text:1b}}
setblock -18 66 28 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 17 64 27 19 64 30 minecraft:smooth_quartz
fill 17 65 29 19 69 29 minecraft:polished_blackstone
setblock 18 69 29 minecraft:cyan_concrete
setblock 18 68 28 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["EXPLORE FREELY","All buildings open","Press for a guide","Mission is optional"],color:"white",has_glowing_text:1b}}
setblock 18 66 28 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 8 64 -49 16 64 -45 minecraft:smooth_quartz
fill 8 65 -46 16 71 -46 minecraft:polished_blackstone
setblock 9 70 -46 minecraft:red_concrete
setblock 9 68 -47 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["DOCKER","Awaiting recovery","",""],color:"white",has_glowing_text:1b}}
setblock 11 70 -46 minecraft:red_concrete
setblock 11 68 -47 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["CINEMA","Awaiting recovery","",""],color:"white",has_glowing_text:1b}}
setblock 13 70 -46 minecraft:red_concrete
setblock 13 68 -47 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["ZFS","Awaiting recovery","",""],color:"white",has_glowing_text:1b}}
setblock 15 70 -46 minecraft:red_concrete
setblock 15 68 -47 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["BACKUP","Awaiting recovery","",""],color:"white",has_glowing_text:1b}}
setblock 12 66 -47 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["UNRAID HQ","Return all 4 signals","Press button below","to bring HQ online"],color:"white",has_glowing_text:1b}}
setblock 12 65 -47 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 21 64 -48 23 64 -45 minecraft:smooth_quartz
fill 21 65 -46 23 69 -46 minecraft:polished_blackstone
setblock 22 69 -46 minecraft:blue_concrete
setblock 22 68 -47 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["WHALE LOUNGE","Bonus after mission","Press to visit","Return button inside"],color:"white",has_glowing_text:1b}}
setblock 22 66 -47 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 89 64 28 91 64 31 minecraft:smooth_quartz
fill 89 65 30 91 69 30 minecraft:polished_blackstone
setblock 90 69 30 minecraft:orange_concrete
setblock 90 68 29 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["A-01 / ORANGE","Spare cables","Delivery terminal","Press to scan"],color:"white",has_glowing_text:1b}}
setblock 90 66 29 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 95 64 28 97 64 31 minecraft:smooth_quartz
fill 95 65 30 97 69 30 minecraft:polished_blackstone
setblock 96 69 30 minecraft:blue_concrete
setblock 96 68 29 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["B-02 / BLUE","Recovery module","Delivery terminal","Press to scan"],color:"white",has_glowing_text:1b}}
setblock 96 66 29 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 101 64 28 103 64 31 minecraft:smooth_quartz
fill 101 65 30 103 69 30 minecraft:polished_blackstone
setblock 102 69 30 minecraft:red_concrete
setblock 102 68 29 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["C-03 / RED","Old keyboards","Delivery terminal","Press to scan"],color:"white",has_glowing_text:1b}}
setblock 102 66 29 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 109 65 5 111 69 5 minecraft:polished_blackstone
setblock 110 68 4 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["CARGO MANIFEST","HQ needs B-02","Find the BLUE parcel","Between cargo homes"],color:"white",has_glowing_text:1b}}
fill -106 64 -21 -104 64 -18 minecraft:smooth_quartz
fill -106 65 -19 -104 69 -19 minecraft:polished_blackstone
setblock -105 69 -19 minecraft:purple_concrete
setblock -105 68 -20 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["SHOWTIME: THREE","Check tonight's poster","in the auditorium","Press to select"],color:"white",has_glowing_text:1b}}
setblock -105 66 -20 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -101 64 -21 -99 64 -18 minecraft:smooth_quartz
fill -101 65 -19 -99 69 -19 minecraft:polished_blackstone
setblock -100 69 -19 minecraft:purple_concrete
setblock -100 68 -20 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["SHOWTIME: SEVEN","Check tonight's poster","in the auditorium","Press to select"],color:"white",has_glowing_text:1b}}
setblock -100 66 -20 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -96 64 -21 -94 64 -18 minecraft:smooth_quartz
fill -96 65 -19 -94 69 -19 minecraft:polished_blackstone
setblock -95 69 -19 minecraft:purple_concrete
setblock -95 68 -20 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["SHOWTIME: NINE","Check tonight's poster","in the auditorium","Press to select"],color:"white",has_glowing_text:1b}}
setblock -95 66 -20 minecraft:stone_button[face=wall,facing=north,powered=false]
setblock -78 69 -3 minecraft:dark_oak_wall_sign[facing=west]{is_waxed:1b,front_text:{messages:["TONIGHT ONLY","Seven servers sleeping","Show starts at SEVEN","Return to ticket desk"],color:"white",has_glowing_text:1b}}
fill -96 64 -121 -94 64 -118 minecraft:smooth_quartz
fill -96 65 -119 -94 69 -119 minecraft:polished_blackstone
setblock -95 69 -119 minecraft:blue_concrete
setblock -95 68 -120 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["BLUE","ZFS recovery sequence","Find the pool clue","Press one at a time"],color:"white",has_glowing_text:1b}}
setblock -95 66 -120 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -92 64 -121 -90 64 -118 minecraft:smooth_quartz
fill -92 65 -119 -90 69 -119 minecraft:polished_blackstone
setblock -91 69 -119 minecraft:purple_concrete
setblock -91 68 -120 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["PURPLE","ZFS recovery sequence","Find the pool clue","Press one at a time"],color:"white",has_glowing_text:1b}}
setblock -91 66 -120 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -88 64 -121 -86 64 -118 minecraft:smooth_quartz
fill -88 65 -119 -86 69 -119 minecraft:polished_blackstone
setblock -87 69 -119 minecraft:yellow_concrete
setblock -87 68 -120 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["YELLOW","ZFS recovery sequence","Find the pool clue","Press one at a time"],color:"white",has_glowing_text:1b}}
setblock -87 66 -120 minecraft:stone_button[face=wall,facing=north,powered=false]
setblock -61 69 -98 minecraft:dark_oak_wall_sign[facing=west]{is_waxed:1b,front_text:{messages:["POOL RECOVERY","BLUE - PURPLE","BLUE - YELLOW","Enter at north console"],color:"white",has_glowing_text:1b}}
fill -140 65 -110 -126 67 -90 minecraft:air
fill -140 65 -110 -126 66 -90 minecraft:stone_bricks
fill -131 65 -109 -131 66 -109 minecraft:air
fill -133 65 -101 -133 66 -101 minecraft:air
fill -131 65 -103 -131 66 -103 minecraft:air
fill -133 65 -107 -133 66 -107 minecraft:air
fill -131 65 -91 -131 66 -91 minecraft:air
fill -129 65 -101 -129 66 -101 minecraft:air
fill -131 65 -97 -131 66 -97 minecraft:air
fill -133 65 -95 -133 66 -95 minecraft:air
fill -129 65 -107 -129 66 -107 minecraft:air
fill -129 65 -95 -129 66 -95 minecraft:air
fill -139 65 -105 -139 66 -105 minecraft:air
fill -139 65 -99 -139 66 -99 minecraft:air
fill -135 65 -105 -135 66 -105 minecraft:air
fill -137 65 -109 -137 66 -109 minecraft:air
fill -137 65 -97 -137 66 -97 minecraft:air
fill -139 65 -93 -139 66 -93 minecraft:air
fill -135 65 -99 -135 66 -99 minecraft:air
fill -137 65 -103 -137 66 -103 minecraft:air
fill -137 65 -91 -137 66 -91 minecraft:air
fill -135 65 -93 -135 66 -93 minecraft:air
fill -127 65 -105 -127 66 -105 minecraft:air
fill -127 65 -99 -127 66 -99 minecraft:air
fill -127 65 -93 -127 66 -93 minecraft:air
fill -131 65 -105 -131 66 -105 minecraft:air
fill -133 65 -109 -133 66 -109 minecraft:air
fill -131 65 -99 -131 66 -99 minecraft:air
fill -133 65 -103 -133 66 -103 minecraft:air
fill -133 65 -91 -133 66 -91 minecraft:air
fill -129 65 -97 -129 66 -97 minecraft:air
fill -131 65 -93 -131 66 -93 minecraft:air
fill -133 65 -97 -133 66 -97 minecraft:air
fill -129 65 -103 -129 66 -103 minecraft:air
fill -129 65 -91 -129 66 -91 minecraft:air
fill -129 65 -109 -129 66 -109 minecraft:air
fill -139 65 -107 -139 66 -107 minecraft:air
fill -139 65 -95 -139 66 -95 minecraft:air
fill -135 65 -101 -135 66 -101 minecraft:air
fill -137 65 -105 -137 66 -105 minecraft:air
fill -139 65 -101 -139 66 -101 minecraft:air
fill -135 65 -107 -135 66 -107 minecraft:air
fill -135 65 -95 -135 66 -95 minecraft:air
fill -137 65 -99 -137 66 -99 minecraft:air
fill -127 65 -107 -127 66 -107 minecraft:air
fill -137 65 -93 -137 66 -93 minecraft:air
fill -127 65 -101 -127 66 -101 minecraft:air
fill -127 65 -95 -127 66 -95 minecraft:air
fill -133 65 -105 -133 66 -105 minecraft:air
fill -131 65 -107 -131 66 -107 minecraft:air
fill -131 65 -95 -131 66 -95 minecraft:air
fill -133 65 -99 -133 66 -99 minecraft:air
fill -129 65 -105 -129 66 -105 minecraft:air
fill -131 65 -101 -131 66 -101 minecraft:air
fill -133 65 -93 -133 66 -93 minecraft:air
fill -129 65 -99 -129 66 -99 minecraft:air
fill -139 65 -109 -139 66 -109 minecraft:air
fill -129 65 -93 -129 66 -93 minecraft:air
fill -137 65 -107 -137 66 -107 minecraft:air
fill -139 65 -103 -139 66 -103 minecraft:air
fill -135 65 -109 -135 66 -109 minecraft:air
fill -139 65 -91 -139 66 -91 minecraft:air
fill -137 65 -101 -137 66 -101 minecraft:air
fill -139 65 -97 -139 66 -97 minecraft:air
fill -135 65 -103 -135 66 -103 minecraft:air
fill -135 65 -91 -135 66 -91 minecraft:air
fill -137 65 -95 -137 66 -95 minecraft:air
fill -135 65 -97 -135 66 -97 minecraft:air
fill -127 65 -109 -127 66 -109 minecraft:air
fill -127 65 -97 -127 66 -97 minecraft:air
fill -127 65 -103 -127 66 -103 minecraft:air
fill -127 65 -91 -127 66 -91 minecraft:air
fill -132 65 -109 -132 66 -109 minecraft:air
fill -131 65 -108 -131 66 -108 minecraft:air
fill -132 65 -107 -132 66 -107 minecraft:air
fill -133 65 -106 -133 66 -106 minecraft:air
fill -134 65 -105 -134 66 -105 minecraft:air
fill -135 65 -106 -135 66 -106 minecraft:air
fill -136 65 -107 -136 66 -107 minecraft:air
fill -137 65 -106 -137 66 -106 minecraft:air
fill -137 65 -104 -137 66 -104 minecraft:air
fill -137 65 -102 -137 66 -102 minecraft:air
fill -137 65 -100 -137 66 -100 minecraft:air
fill -138 65 -99 -138 66 -99 minecraft:air
fill -139 65 -100 -139 66 -100 minecraft:air
fill -139 65 -102 -139 66 -102 minecraft:air
fill -139 65 -104 -139 66 -104 minecraft:air
fill -139 65 -106 -139 66 -106 minecraft:air
fill -139 65 -108 -139 66 -108 minecraft:air
fill -138 65 -109 -138 66 -109 minecraft:air
fill -136 65 -109 -136 66 -109 minecraft:air
fill -139 65 -98 -139 66 -98 minecraft:air
fill -138 65 -97 -138 66 -97 minecraft:air
fill -136 65 -97 -136 66 -97 minecraft:air
fill -135 65 -96 -135 66 -96 minecraft:air
fill -135 65 -94 -135 66 -94 minecraft:air
fill -134 65 -93 -134 66 -93 minecraft:air
fill -133 65 -92 -133 66 -92 minecraft:air
fill -134 65 -91 -134 66 -91 minecraft:air
fill -136 65 -91 -136 66 -91 minecraft:air
fill -137 65 -92 -137 66 -92 minecraft:air
fill -137 65 -94 -137 66 -94 minecraft:air
fill -138 65 -95 -138 66 -95 minecraft:air
fill -139 65 -94 -139 66 -94 minecraft:air
fill -139 65 -92 -139 66 -92 minecraft:air
fill -132 65 -91 -132 66 -91 minecraft:air
fill -130 65 -91 -130 66 -91 minecraft:air
fill -129 65 -92 -129 66 -92 minecraft:air
fill -128 65 -93 -128 66 -93 minecraft:air
fill -127 65 -92 -127 66 -92 minecraft:air
fill -127 65 -94 -127 66 -94 minecraft:air
fill -127 65 -96 -127 66 -96 minecraft:air
fill -127 65 -98 -127 66 -98 minecraft:air
fill -128 65 -99 -128 66 -99 minecraft:air
fill -129 65 -100 -129 66 -100 minecraft:air
fill -130 65 -101 -130 66 -101 minecraft:air
fill -131 65 -102 -131 66 -102 minecraft:air
fill -132 65 -103 -132 66 -103 minecraft:air
fill -134 65 -103 -134 66 -103 minecraft:air
fill -135 65 -102 -135 66 -102 minecraft:air
fill -135 65 -100 -135 66 -100 minecraft:air
fill -134 65 -99 -134 66 -99 minecraft:air
fill -132 65 -99 -132 66 -99 minecraft:air
fill -131 65 -98 -131 66 -98 minecraft:air
fill -132 65 -97 -132 66 -97 minecraft:air
fill -133 65 -96 -133 66 -96 minecraft:air
fill -132 65 -95 -132 66 -95 minecraft:air
fill -131 65 -94 -131 66 -94 minecraft:air
fill -130 65 -95 -130 66 -95 minecraft:air
fill -129 65 -96 -129 66 -96 minecraft:air
fill -133 65 -100 -133 66 -100 minecraft:air
fill -131 65 -104 -131 66 -104 minecraft:air
fill -130 65 -105 -130 66 -105 minecraft:air
fill -129 65 -104 -129 66 -104 minecraft:air
fill -128 65 -103 -128 66 -103 minecraft:air
fill -127 65 -102 -127 66 -102 minecraft:air
fill -127 65 -104 -127 66 -104 minecraft:air
fill -127 65 -106 -127 66 -106 minecraft:air
fill -128 65 -107 -128 66 -107 minecraft:air
fill -129 65 -108 -129 66 -108 minecraft:air
fill -128 65 -109 -128 66 -109 minecraft:air
fill -133 65 -111 -133 67 -109 minecraft:air
fill -134 65 -90 -132 69 -90 minecraft:polished_blackstone
setblock -133 68 -91 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["RECOVERY KEY","You found the backup","Press to recover","Then return to HQ"],color:"white",has_glowing_text:1b}}
setblock -133 66 -91 minecraft:stone_button[face=wall,facing=north,powered=false]
setblock -133 69 -112 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["BACKUP MAZE","Find the recovery key","No traps, no timer","Everyone may explore"],color:"white",has_glowing_text:1b}}
tp @e[type=minecraft:iron_golem,x=-142,y=63,z=-112,dx=18,dy=15,dz=25] -130 65 -116
fill 141 66 54 151 69 60 minecraft:air
fill 141 65 54 151 65 60 minecraft:blue_concrete
setblock 142 65 55 minecraft:sea_lantern
setblock 142 65 59 minecraft:sea_lantern
setblock 150 65 55 minecraft:sea_lantern
setblock 150 65 59 minecraft:sea_lantern
setblock 143 66 59 minecraft:spruce_stairs[facing=north]
setblock 144 66 59 minecraft:spruce_stairs[facing=north]
setblock 145 66 59 minecraft:spruce_stairs[facing=north]
setblock 146 66 59 minecraft:spruce_stairs[facing=north]
setblock 147 66 59 minecraft:spruce_stairs[facing=north]
setblock 148 66 59 minecraft:spruce_stairs[facing=north]
setblock 149 66 59 minecraft:spruce_stairs[facing=north]
fill 144 66 53 148 69 53 minecraft:blue_concrete
setblock 146 68 54 minecraft:dark_oak_wall_sign[facing=south]{is_waxed:1b,front_text:{messages:["DOCKER WHALE","Maintenance lounge","You earned a break","Press to return"],color:"white",has_glowing_text:1b}}
setblock 146 66 54 minecraft:stone_button[face=wall,facing=south,powered=false]
fill 30 64 -80 32 64 -77 minecraft:smooth_quartz
fill 30 65 -78 32 69 -78 minecraft:polished_blackstone
setblock 31 69 -78 minecraft:red_concrete
setblock 31 68 -79 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["RESET MISSION","For everyone!","Press ARM first","Then CONFIRM nearby"],color:"white",has_glowing_text:1b}}
setblock 31 66 -79 minecraft:stone_button[face=wall,facing=north,powered=false]
fill 34 64 -80 36 64 -77 minecraft:smooth_quartz
fill 34 65 -78 36 69 -78 minecraft:polished_blackstone
setblock 35 69 -78 minecraft:red_concrete
setblock 35 68 -79 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["CONFIRM RESET","Only within 5 seconds","Mission progress only","Town stays intact"],color:"white",has_glowing_text:1b}}
setblock 35 66 -79 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -123 64 -56 -121 64 -53 minecraft:smooth_quartz
fill -123 65 -54 -121 69 -54 minecraft:polished_blackstone
setblock -122 69 -54 minecraft:light_blue_concrete
setblock -122 68 -55 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["SSD TIME TRIAL","One racer at a time","Press to board a boat","SHIFT cancels safely"],color:"white",has_glowing_text:1b}}
setblock -122 66 -55 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -119 64 -56 -117 64 -53 minecraft:smooth_quartz
fill -119 65 -54 -117 69 -54 minecraft:polished_blackstone
setblock -118 69 -54 minecraft:white_concrete
setblock -118 68 -55 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["CANCEL TIME TRIAL","Only the racer can","cancel their own run","Mission is unchanged"],color:"white",has_glowing_text:1b}}
setblock -118 66 -55 minecraft:stone_button[face=wall,facing=north,powered=false]
fill -142 67 -40 -142 70 -40 minecraft:light_blue_concrete
fill -125 67 -40 -125 70 -40 minecraft:light_blue_concrete
fill -142 71 -40 -125 71 -40 minecraft:light_blue_concrete
setblock -130 70 -40 minecraft:light_blue_concrete
setblock -130 70 -41 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["START / FINISH","Follow the east lane","south, turn west,","return on west lane"],color:"white",has_glowing_text:1b}}
fill -142 67 55 -142 70 55 minecraft:light_blue_concrete
fill -125 67 55 -125 70 55 minecraft:light_blue_concrete
fill -142 71 55 -125 71 55 minecraft:light_blue_concrete
setblock -130 70 55 minecraft:light_blue_concrete
setblock -130 70 54 minecraft:dark_oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:["CROSS TO WEST","Follow the east lane","south, turn west,","return on west lane"],color:"white",has_glowing_text:1b}}
tp @e[type=minecraft:oak_boat,x=-140,y=60,z=-51,dx=18,dy=12,dz=20] -138 65 -45
setblock -101 74 -29 minecraft:purple_concrete
setblock -99 74 -29 minecraft:purple_concrete
setblock -97 74 -29 minecraft:purple_concrete
scoreboard players set #installed hr 1
function harbour:hud/refresh
forceload remove -144 -112
forceload remove -144 -96
forceload remove -144 -48
forceload remove -144 48
forceload remove -128 -112
forceload remove -128 -96
forceload remove -128 -64
forceload remove -128 -48
forceload remove -128 48
forceload remove -112 -32
forceload remove -96 -128
forceload remove -96 -32
forceload remove -80 -16
forceload remove -64 -112
forceload remove -32 16
forceload remove 0 -64
forceload remove 0 -48
forceload remove 16 -80
forceload remove 16 -64
forceload remove 16 -48
forceload remove 16 16
forceload remove 32 -80
forceload remove 80 16
forceload remove 96 0
forceload remove 96 16
forceload remove 128 48
forceload remove 144 48
tellraw @a {"text":"Unraid Harbour Adventure is ready. Explore freely or use the grey button below the orange plaza marker.","color":"gold"}
