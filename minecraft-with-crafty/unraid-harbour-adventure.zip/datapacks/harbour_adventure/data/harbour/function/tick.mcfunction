execute in minecraft:overworld if score #installed hr matches 1 run function harbour:world_tick
