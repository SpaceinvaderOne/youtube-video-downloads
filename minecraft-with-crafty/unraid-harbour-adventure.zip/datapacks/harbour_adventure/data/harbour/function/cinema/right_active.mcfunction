function harbour:award/cinema
