tellraw @a {"text":"Not tonight's showtime. Look for the poster inside the auditorium.","color":"yellow"}
