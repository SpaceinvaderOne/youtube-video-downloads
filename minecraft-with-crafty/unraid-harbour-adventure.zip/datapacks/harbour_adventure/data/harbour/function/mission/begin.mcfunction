scoreboard players set #state hr 1
tellraw @a {"text":"RECOVERY MISSION: Docker delivery, cinema showtime, ZFS sequence and backup key. Complete them in any order.","color":"gold"}
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1 1
