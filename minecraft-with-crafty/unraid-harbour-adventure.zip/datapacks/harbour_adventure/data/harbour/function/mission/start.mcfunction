execute as @p[distance=..6] run function harbour:player/join
execute if score #state hr matches 0 run function harbour:mission/begin
execute if score #state hr matches 3 run tellraw @a {"text":"The lab is already online! Explore the bonus lounge, or reset the mission in the maintenance nook.","color":"green"}
function harbour:hud/refresh
