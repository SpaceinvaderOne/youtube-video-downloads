scoreboard players set #state hr 3
title @a times 10 60 20
title @a title {"text":"SYSTEM ONLINE","color":"gold"}
title @a subtitle {"text":"You brought the homelab back online!","color":"white"}
function harbour:hud/refresh
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
summon minecraft:firework_rocket 3 76 -45 {LifeTime:25,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;15759397,16753920],has_twinkle:true}]}}}}
summon minecraft:firework_rocket 12 76 -45 {LifeTime:25,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;15759397,16753920],has_twinkle:true}]}}}}
summon minecraft:firework_rocket 21 76 -45 {LifeTime:25,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;15759397,16753920],has_twinkle:true}]}}}}
tellraw @a {"text":"MISSION COMPLETE! The blue console beside HQ now takes you into the Docker whale's secret lounge.","color":"aqua"}
