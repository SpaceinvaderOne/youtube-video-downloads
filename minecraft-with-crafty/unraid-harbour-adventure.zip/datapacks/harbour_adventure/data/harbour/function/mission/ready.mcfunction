scoreboard players set #state hr 2
title @a times 10 60 20
title @a title {"text":"ALL SIGNALS RESTORED","color":"gold"}
title @a subtitle {"text":"Return to the console outside Unraid HQ","color":"white"}
tellraw @a {"text":"All four tasks complete! Return outside Unraid HQ at XYZ 12, 65, -50. Start recording if you like, then right-click the final grey button for the celebration!","color":"green"}
