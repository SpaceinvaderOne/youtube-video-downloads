execute if score #state hr matches 2 run function harbour:mission/celebrate
execute if score #state hr matches 0..1 run tellraw @a {"text":"Four signals are needed: Docker, cinema, ZFS and backup. The town stays open while you explore.","color":"yellow"}
