scoreboard objectives add hr dummy
scoreboard objectives add hr_best dummy
scoreboard objectives add hr_boat dummy
scoreboard objectives add hr_last dummy
data modify storage harbour:state initialized set value 1b
scoreboard players set #twenty hr 20
scoreboard players set #two hr 2
scoreboard players set #installed hr 0
scoreboard players set #state hr 0
scoreboard players set #docker hr 0
scoreboard players set #cinema hr 0
scoreboard players set #zfs hr 0
scoreboard players set #backup hr 0
scoreboard players set #sequence hr 0
scoreboard players set #armed hr 0
scoreboard players set #race hr 0
scoreboard players set #time hr 0
scoreboard players set #lap hr 0
scoreboard players set #clock hr 0
scoreboard players set #total hr 0
bossbar add harbour:progress "Bring the homelab online"
bossbar set harbour:progress max 4
bossbar set harbour:progress color yellow
bossbar set harbour:progress visible false
